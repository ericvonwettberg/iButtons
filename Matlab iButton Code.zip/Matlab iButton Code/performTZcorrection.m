% Written by EDC 2015 (2015_01_07)
function [ corrTZ ] = performTZcorrection()
fprintf('Correction factor for different time zones assumes the times are originally set to  EST (US).\nThe location time zone should be input using UTC standard (e.g. -8). U.S. time zone codes are accepted.\nPST(-8), MST(-7), CST(-6) or EST(-5). Note: Turkey(+2), Ethiopia(+3)\nIf the programmed time is not EST please add programming location time zone code seperated by a space then the recording location time zone code.\n(e.x.''-5 +2'')');
correctT = input('Please input time zone code(s) for sensor location.', 's');
TZinput = strsplit(correctT);
TZs = {'PST','MST','CST','EST'};
if length(TZinput) > 2
    display('Error. Too many input variables!');
    return
elseif length(TZinput) == 2
    if strcmp(TZinput(1),TZs) > 0
        TZp = strmatch(TZinput(1),TZs,'exact') - 9;
    else
        TZp = str2double(TZinput(1));
    end
    if strcmp(TZinput(2),TZs) > 0
        TZl = strmatch(TZinput(2),TZs,'exact') - 9;
    else
        TZl = str2double(TZinput(2));
    end
    tzcf = TZl - TZp;
else
    if strcmp(TZinput,TZs) > 0
        tzcf = strmatch(TZinput,TZs,'exact') + 5;
    else
        tzcf = str2double(TZinput) + 5;
    end
end
corrTZ = tzcf/24;
end
% [*]