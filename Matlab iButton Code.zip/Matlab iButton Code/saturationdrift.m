function [ driftMatrix ] = saturationdrift( tcorrMatrix, htcompMatrix, interval )
%SATURATIONDRIFT takes in corrected temperature and temperature compensated
%relative humidity data and corrects, when needed, any relative humidity data
%to compensate for high humidity at time of data aquisition.
%   saturationdrift requiures to input arrays (type double) one for the
%   calibration corrected temperature readings and the other for the
%   temperature compensated relative humidity readings. The relative humidity
%   is read and adjusted to factor for times when the sensor was exposed to
%   high relative humidity (>70%). The relative humidity sensor experiences
%   drift, due to saturation, at relative humidity levels higher than 70%.
%   The output is an array (type double) of drift compensated relative humidity
%   readings.
%   
%   function format: [ driftArray ] = saturationdrift( tcorrArray, htcompArray, interval );
%
%   Default assumption of 4 hour intervals between readings
%   Written by EDC 2015 (20150216)

if nargin < 2
    msgID = 'ERRFUN:MissingArgs';
    msg = 'Function requires more input. Please use the following format: tempcompensation( tcorrArray, hcorrArray )';
    baseException = MException(msgID,msg);
    throw(baseException)
elseif nargin == 2
    interval = 4;
end
% Input data
Tcorr = tcorrMatrix; %type double
Htcomp = htcompMatrix; %type double
HScorr = double.empty(length(Htcomp),0);
I1 = interval;
I2 = interval - 1;
%% Go through humidity readings and determine when to apply drift compensation
rank = double.empty(0,length(Htcomp));
j = 0;
for i = 1:length(Htcomp)
    if Htcomp(i) >= 70
        j = j + 1;
        rank(i) = j;
    else
        rank(i) = 0;
        j = 0;
    end
end
i = 1;
while i <= length(Htcomp)
    % look for high humidity readings (>=70%)
    if rank(i) > 1
        %... Apply saturation drift partial correction factor for times exceeding
        % ## hours, partial correction is considered constant.
        %if rank >= num
        %    partialcorr = ;
        %    HScorr = HTcorr - partialcorr;
        %end
        
        % Saturation Drift Compensation
        r = rank(i)-1;
        corrfactor = 0;
        %tic
        for m = 1:r
            Tk = mean(Tcorr(i-r:i-r+m)); % Average temp
            ARHk = mean(Htcomp(i-r:i-r+m)); % Average relative humidity
            partialcorr = 0;
            q = I1*m-I2; % Summation limits
            N = I1*m;
            for k = q:N
                partialcorr = partialcorr + k*2.54^(-0.3502*k); % Summation
            end
            % Calculate drift correction factor
            Tkp = (1+(Tk-25)/100);
            corrfactor = corrfactor + 0.0156*ARHk*partialcorr/Tkp;
        end
        % Apply saturation drift partial correction factor
        HScorr(i,1) = Htcomp(i) - corrfactor;
        i = i + 1;
        %toc
    else
        HScorr(i,1) = Htcomp(i);
        i = i + 1;
    end
end
%ncheck = find(HScorr < 0);
%for i = 1:numel(ncheck)
%   if ncheck(i) == 1 || ncheck(i) == numel(HScorr)
%       HScorr(ncheck(i)) = NaN;
%   elseif HScorr(ncheck(i)-1) < 50 && HScorr(ncheck(i)-1) > 0 && HScorr(ncheck(i)+1) < 50
%       HScorr(ncheck(i)) = 0; % No reading after a dry reading, not before drowning
%   elseif HScorr(ncheck(i)+1) < 50 && HScorr(ncheck(i)+1) > 0 && isnan(HScorr(ncheck(i)-1))
%       HScorr(ncheck(i)) = 0; % No reading before a dry reading, not after a drowning
%   elseif HScorr(ncheck(i)-1) > 50 && HScorr(ncheck(i)-1) < 100 && (HScorr(ncheck(i)+1) < 0 || HScorr(ncheck(i)+1) > 50)
%       HScorr(ncheck(i)) = 100; % No reading after a wet reading, not before drying
%   elseif HScorr(ncheck(i)+1) > 50 && (isnan(HScorr(ncheck(i)-1)) || HScorr(ncheck(i)-1) > 50)
%       HScorr(ncheck(i)) = 100; % No reading before a wet reading, not after drying
%   else
%       HScorr(ncheck(i)) = NaN;
%   end
%end
driftMatrix = HScorr;    
end
% [*]