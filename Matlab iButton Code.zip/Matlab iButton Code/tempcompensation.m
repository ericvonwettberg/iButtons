function [ tcompMatrix ] = tempcompensation( tcorrMatrix, hcorrMatrix )
%TEMPCOMPENSATION takes in corrected temperature and relative humidity data
%and corrects the relative humidity data in order to compensate for the
%temperature at time of data aquisition.
%   tempcompensation requiures to input arrays (type double) one for the
%   calibration corrected temperature readings and the other for the
%   calibration corrected relative humidity readings. The relative humidity
%   is adjusted to factor in the temperature at which the reading was
%   taken. The relative humidity sensor is calibrated to take readings at
%   25*C. The output is an array (type double) of corrected relative humidity
%   readings.
%   
%   function format: [ tcompArray ] = tempcompensation( tcorrArray, hcorrArray );

if nargin < 2
    msgID = 'ERRFUN:MissingArgs';
    msg = 'Function requires more input. Please use the following format: tempcompensation( tcorrArray, hcorrArray )';
    baseException = MException(msgID,msg);
    throw(baseException)
end

% Input data
Tcorr = tcorrMatrix;
Hcorr = hcorrMatrix;

% Constants
K = 0.0307;
a = 0.0035; % *C-1
b = 0.000043; % *C-2
d = 0.000002; % *C-2
% empty double array for data
HTcorr = double.empty(length(Hcorr),0);
% Determine which value to use for constant c
for i = 1:length(Tcorr)
    if Tcorr(i) > 15
        c = 0.00001;
    else
        c = -0.00005;
    end
    HTcorr(i,1) = ((Hcorr(i)*K+a*(Tcorr(i)-25)-b*(Tcorr(i)-25)^2)/(K+c*(Tcorr(i)-25)-d*(Tcorr(i)-25)^2));
end
tcompMatrix = HTcorr;
end

