% Written by EDC 2015 (20150409)
[FileName,PathName,FilterIndex] = uigetfile('*.csv','Select iButton Data','MultiSelect','on');
if FilterIndex == 0
    return %If no files selected program exits
end
if ischar(FileName)
    FileName = {FileName};
end
numF = size(FileName,2); %Number of files selected
disp(['Number of files selected: ',num2str(numF)]);
%fname = 'C:\Users\Manny\Documents\iButton Data\Oct_14\09.11.2014 ibuttons read\cermik\ds1921_cermik_103_temp.csv';
%fname = 'C:\Users\Manny\Documents\test.txt';
for i = 1:numF
    fname = strcat(PathName,FileName{i});
    fprintf('Processing file: %s...\n',FileName{i})
    fid = fopen(fname,'rt+');
    nl = 1;
    corr = 0;
    check = false;
    while ~check && (~feof(fid))
        line = fgetl(fid);
        if strncmp('Date/Time',line,9)
            check = true;
        end
    end
    while (~feof(fid))
        %fprintf('Scanning data line: %d\n',nl)
        lnum = ftell(fid);
        cline = fgetl(fid);
        commas = strfind(cline,',');
        if numel(commas) == 3
            fseek(fid,lnum,'bof');
            ncline = [cline(1:commas(3)-1),'.', cline(commas(3)+1:end)];
            fprintf(fid,'%s',ncline);
            fseek(fid,0,'cof');
            corr = corr + 1;
        elseif numel(commas) > 3
            fprintf(cline)
            break
        end
        nl = nl + 1;
    end
    fclose(fid);
    fprintf('%d data lines scanned. %d corrections performed.\n',nl,corr)
end