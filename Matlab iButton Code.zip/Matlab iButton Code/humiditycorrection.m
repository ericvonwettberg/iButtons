function [ corrMatrix ] = humiditycorrection( humidityMatrix, standards )
%HUMIDITYCORRECTION accepts iButton humidity array and calibration standards then outputs
%an array of corrected humidity readings.
%   humiditycorrection applies the iButton internal calibration standards to
%   generate corrected humidity readings. Humidity readings will be corrected
%   according to the methods created by Maxim and listed in the DS1923
%   iButton product manual. The function accepts an array of humidity
%   readings (type double) and a calibration standard string (16 hexadecimal
%   pairs; e.g. 00 00 00 00 00 00 00 00). The output is an array of
%   corrected humidity readings (type double).
%
%   function format: Hcorrected = humiditycorrection( humidityArray, standards );

if nargin < 2
    msgID = 'ERRFUN:MissingArgs';
    msg = 'Function requires more input. Please use the following format: humiditycorrection( humidityArray, standards )';
    baseException = MException(msgID,msg);
    throw(baseException)
end

Humid = humidityMatrix;
CalibStand = strsplit(standards);
StandTitles = {'Hr1H','Hr1L','Hc1H','Hc1L','Hr2H','Hr2L','Hc2H','Hc2L','Hr3H','Hr3L','Hc3H','Hc3L'};
% Retrieve and convert binary standard segments
for i = 9:20
    eval([StandTitles{i-8} ' = ' num2str(hex2dec(CalibStand(i))) ';']);
end
% Preparation of correction values using method as reported by Maxim in the
% DS1923 iButton data sheet.
%

% Calculate standard values from standard segments
Hr1 = (((Hr1H*256+Hr1L)*5.02/65536-0.958)/0.0307);
Hr2 = (((Hr2H*256+Hr2L)*5.02/65536-0.958)/0.0307);
Hr3 = (((Hr3H*256+Hr3L)*5.02/65536-0.958)/0.0307);
Hc1 = (((Hc1H*256+Hc1L)*5.02/65536-0.958)/0.0307);
Hc2 = (((Hc2H*256+Hc2L)*5.02/65536-0.958)/0.0307);
Hc3 = (((Hc3H*256+Hc3L)*5.02/65536-0.958)/0.0307);
% Determine error
HErr1 = Hc1-Hr1;
HErr2 = Hc2-Hr2;
HErr3 = Hc3-Hr3;
% Calculate correction factors
E = (((Hr2^2-Hr1^2)*(HErr3-HErr1)+Hr3^2*(HErr1-HErr2)+Hr1^2*(HErr2-HErr1))/((Hr2^2-Hr1^2)*(Hr3-Hr1)+(Hr3^2-Hr1^2)*(Hr1-Hr2)));
D = ((HErr2-HErr1+E*(Hr1-Hr2))/(Hr2^2-Hr1^2));
F = (HErr1-D*Hr1^2-E*Hr1);

%   Execution of correction
corrMatrix = Humid - (D*Humid.^2 + E*Humid + F);

end

% [*]