function [ limits ] = tableLimits( datelist, method, Yearly)
%%TABLELIMITS: Calculates date limits for tables
% Takes in a vertical number array of dates and a year format and creates a
% table of the start dates for year blocks.
% Output = [Start Datenum],[Start Position],[Complete?]
% Written by EDC 2015 (2015_04_06)
if nargin == 1
    method = 'Standard';
    Yearly = true;
elseif nargin == 2
    Yearly = true;
end
method = validatestring(method,{'Standard','ToD'});
dates = [floor(datelist(1));floor(datelist(end))];
datesv = datevec(dates);
if Yearly
    datesv(:,2) = 1;
else
    datesv(:,2) = 11;
end
datesv(:,3) = 1;
datesv(:,4:6) = 0;
if strcmp(method,'ToD')
    timeshift = 1/6;
else
    timeshift = 0;
end
if datelist(1,1) < datenum(datesv(1,:))
    datesv(1,:) = datesv(1,:) + [-1 0 0 0 0 0];
end
if datelist(end,1) < datenum(datesv(2,:))
    datesv(2,:) = datesv(2,:) + [-1 0 0 0 0 0];
end
if isequal(datesv(1,:),datesv(2,:))
    years = [datenum(datesv(1,:)) + timeshift, 1];
    yend = datenum(datesv(2,:)+[1 0 0 0 0 0]) + timeshift;
    edate = (floor(datelist(end,1)) + timeshift) == yend || (floor(datelist(end,1)) + timeshift) == yend - 1;
else
    years = [datenum(datesv(1,:)) + timeshift,1];
    ydiff = datesv(2,1) - datesv(1,1);
    if ydiff > 1
        for i = 1:ydiff
            years(i+1,1) = datenum(datesv(1,:)+[i 0 0 0 0 0]) + timeshift;
            years(i+1,2) = find(datelist>=years(i+1,1),1,'first');
        end
        for i = 1:ydiff
            if i == ydiff
                yend = datenum(datesv(1,:)+[i+1 0 0 0 0 0]) + timeshift;
                sdate = (floor(datelist(years(i+1,2),1)) + timeshift) == years(i+1,1);
                edate = (floor(datelist(end,1)) + timeshift) == yend || (floor(datelist(end,1)) + timeshift) == yend - 1;
            else
                sdate = (floor(datelist(years(i+1,2),1)) + timeshift) == years(i+1,1);
                edate = (floor(datelist(years(i+2,2)-1,1)) + timeshift) == years(i+2,1) || (floor(datelist(years(i+2,2)-1,1)) + timeshift) == years(i+2,1) - 1;
            end
            years(i+1,3) = sdate && edate;
        end
    else
        years(2,1) = datenum(datesv(2,:)) + timeshift;
        years(2,2) = find(datelist>=years(2,1),1,'first');
        yend = datenum(datesv(2,:)+[1 0 0 0 0 0]) + timeshift;
        sdate = (floor(datelist(years(2,2),1)) + timeshift) == years(2,1);
        edate = (floor(datelist(end,1)) + timeshift) == yend || (floor(datelist(end,1)) + timeshift) == yend - 1;
        years(2,3) = sdate && edate;
    end
    edate = (floor(datelist(years(2,2)-1,1)) + timeshift) == years(2,1) || (floor(datelist(years(2,2)-1,1)) + timeshift) == years(2,1) - 1;
end
sdate = (floor(datelist(1,1)) + timeshift) == years(1,1);
years(1,3) = sdate && edate;
%% Output
limits = years;
end
% [*]