%% DetermineSiteAverage:
% Reads .mat iButton data files and creates a data file
% with data of the site averaged data from all site sensor data.
% DS1921G and DS1923 data is averaged separately.
% Written by EDC 2015 (20150120)
fprintf('Welcome to the Site Average iButton Data Program\nThis program will average iButton sensor data tables into site specific tables.\nNote: Thermochron and Hygrochron temperature data are averaged separately.\n');
ready = input('Ready to begin? (y/n)','s'); %Allows user to exit program
if ~strcmp(ready,'y')
    return
end
% Allows users to select multiple files from a folder, constrained to .csv
% files
fprintf('The data file should have the following naming scheme "iButton[type]Data_[date].mat".\nPlease select the iButton data table files you would like to average.\n');
[FileName,PathName,FilterIndex] = uigetfile('*.mat','Select iButton Data Set','MultiSelect','on');
if FilterIndex == 0
    return %If no files selected program exits
end
if iscell(FileName)
    numF = numel(FileName); %Number of files selected
else
    FileName = {FileName};
    numF = 1;
end
disp(['Number of files selected: ',num2str(numF)]);
% Create and load table lists
for i = 1:numel(FileName)
    if strncmp('iButtonHTData',FileName{i},12)
        HTlist = tableList(FileName{i},'HT_\d*_\d*[ci]');
        eval(['load(''' PathName FileName{i} ''',HTlist{:});']);
        HTlist(end,2) = {[]};
    elseif strncmp('iButtonTData',FileName{i},12)
        Tlist = tableList(FileName{i},'T_\d*_\d*[ci]');
        eval(['load(''' PathName FileName{i} ''',Tlist{:});']);
        checkdt = false(size(Tlist,1),1);
        for j = 1:size(Tlist,1)
            eval(['checkdt(j) = strcmp(' Tlist{j,1} '.Properties.UserData{3},''DS1921G'');'])
        end
        Tlist = Tlist(checkdt);
        Tlist(end,2) = {[]};
    end
end
% Inform user that DS1923 data will not be sorted seperately, by default
disp('This program is set to only interpret DS1921G data individually, DS1923 must be in corrected format (HT table).');
% Save file created
Tstamp = clock; % Timestamp
Tdate = datestr(date);
if eval(['exist(''iButtonAData_' Tdate '.mat'',''file'')']) == 0
    eval(['Afile = ''iButtonAData_' Tdate '.mat'';']);
    eval(['ASEMfile = ''iButtonASEMData_' Tdate '.mat'';']);
else
    eval(['disp([''The output file: "iButtonAData' Tdate '.mat" already exists.'']);']);
    writeover = input('Write over existing file? (y/n)','s');
    if strcmp(writeover,'y')
        eval(['Afile = ''iButtonAData_' Tdate '.mat'';']);
        eval(['ASEMfile = ''iButtonASEMData_' Tdate '.mat'';']);
        disp('Files will be overwritten.');
    else
        disp('Files will not be written over. A new file will be created');
        eval(['Afile = ''iButtonAData_' Tdate '_' num2str(datenum(Tstamp)) '.mat'';']);
        eval(['ASEMfile = ''iButtonASEMData_' Tdate '_' num2str(datenum(Tstamp)) '.mat'';']);
    end
end
save(Afile,'Tstamp');
save(ASEMfile,'Tstamp');
%% Site Correlation
% Create site correlation tables
sitecorrelation
%% Perform Site Average
Leftovers = cell(1,0);
r = 1;
s = 1;
if ~isempty(Tsitelist{1,1})
    tic % Process Thermochron data
    for i = 1:size(Tsitelist,1)
        if isempty(Tsitelist{i,1})
            continue
        end
        eval(['currSite = [' Tsitelist{i,1} '.Properties.UserData{1},''-'',' Tsitelist{i,1} '.Properties.UserData{5}];'])
        if isempty(Tsitelist{i,2})
            Leftovers{r,1} = Tsitelist{i,1};
            r = r + 1;
            eval(['disp(''Site ' currSite ' was not averaged. Only one Thermochron data set available.'');']);
            continue
        end
        eval(['disp(''Processing Thermochron data for site ' currSite ' ...'');']);
        % Grab tables to be processed
        num = find(cellfun(@isempty,Tsitelist(i,:)),1,'first');
        if isempty(num)
            num = size(Tsitelist,2) + 1;
        end
        siteList = cell(num-1,1);
        for j = 1:(num-1)
            eval(['siteList{j,1} = ' Tsitelist{i,j} ';']);
        end
        % Extract data and average
        siteData = iDataExtract(siteList,4);
        siteAvgData = iDataAverage(siteData);
        nameparts = strsplit(Tsitelist{i,1},'_');
        Dates = datestr(siteAvgData(:,1));
        Unit = repmat(siteList{1,1}{1,2},size(siteAvgData,1),1);
        Unit = categorical(Unit,{'C','F'},{'C','F'});
        avgTable = table(Dates,Unit,siteAvgData(:,2));
        eval(['avgTable.Properties.Description = strcat(' Tsitelist{i,1} '.Properties.UserData{1},'' Site Average Data'');']);
        eval(['avgTable.Properties.VariableNames = ' Tsitelist{i,1} '.Properties.VariableNames;']);
        avgTable.Properties.UserData = {'DS1921G'};
        eval(['A' nameparts{1} '_' num2str(Tsitenum{i,1}) '_' nameparts{3} ' = avgTable;']);
        eval(['save(Afile,''A' nameparts{1} '_' num2str(Tsitenum{i,1}) '_' nameparts{3} ''',''-append'')']);
        % Standard Error of Mean
        siteSEM = nanstd(siteData(:,:,2),0,2)/sqrt(size(siteData,2)-sum(isnan(siteData(:,:,2)),2));
        semTable = table(Dates,Unit,siteSEM(:,1));
        eval(['semTable.Properties.Description = strcat(' Tsitelist{i,1} '.Properties.UserData{1},'' Site Standard Error of the Mean'');']);
        eval(['semTable.Properties.VariableNames = ' Tsitelist{i,1} '.Properties.VariableNames;']);
        semTable.Properties.UserData = {'DS1921G'};
        eval(['SSEM' nameparts{1} '_' num2str(Tsitenum{i,1}) '_' nameparts{3} ' = semTable;']);
        eval(['save(ASEMfile,''SSEM' nameparts{1} '_' num2str(Tsitenum{i,1}) '_' nameparts{3} ''',''-append'')']);
    end
    toc
end
if ~isempty(HTsitelist{1,1})
    s = 1;
    tic % Process Hygrochron Data
    for i = 1:size(HTsitelist,1)
        if isempty(HTsitelist{i,1})
            continue
        end
        eval(['currSite = [' HTsitelist{i,1} '.Properties.UserData{1},''-'',' HTsitelist{i,1} '.Properties.UserData{5}];'])
        if isempty(HTsitelist{i,2})
            Leftovers{r,1} = HTsitelist{i,1};
            r = r + 1;
            eval(['disp(''Site ' currSite ' was not averaged. Only one Hygrochron data set available.'');']);
            continue
        end
        eval(['disp(''Processing Hygrochron data for site ' currSite ' ...'');']);
        % Grab tables to be processed
        num = find(cellfun(@isempty,HTsitelist(i,:)),1,'first');
        if isempty(num)
            num = size(HTsitelist,2) + 1;
        end
        siteList = cell(num-1,1);
        for j = 1:(num-1)
            eval(['siteList{j,1} = ' HTsitelist{i,j} ';']);
        end
        % Extract data and average
        siteData = iDataExtract(siteList,4);
        siteAvgData = iDataAverage(siteData);
        nameparts = strsplit(HTsitelist{i,1},'_');
        Dates = datestr(siteAvgData(:,1));
        avgTable = table(Dates,siteAvgData(:,2),siteAvgData(:,3));
        eval(['avgTable.Properties.Description = [' HTsitelist{i,1} '.Properties.UserData{1},'' Site Average '',' HTsitelist{i,1} '.Properties.Description];']);
        eval(['avgTable.Properties.VariableUnits = ' HTsitelist{i,1} '.Properties.VariableUnits([1,3,7]);']);
        eval(['avgTable.Properties.VariableNames = ' HTsitelist{i,1} '.Properties.VariableNames([1,3,7]);']);
        avgTable.Properties.UserData = {'DS1923'};
        eval(['A' nameparts{1} '_' num2str(HTsitenum{i,1}) '_' nameparts{3} ' = avgTable;']);
        eval(['save(Afile,''A' nameparts{1} '_' num2str(HTsitenum{i,1}) '_' nameparts{3} ''',''-append'')']);
        % Standard Error of Mean
        siteSEM1 = nanstd(siteData(:,:,2),0,2)/sqrt(size(siteData,2)-sum(isnan(siteData(:,:,2)),2));
        siteSEM2 = nanstd(siteData(:,:,3),0,2)/sqrt(size(siteData,2)-sum(isnan(siteData(:,:,3)),2));
        semTable = table(Dates,siteSEM1(:,1),siteSEM2(:,1));
        eval(['semTable.Properties.Description = [' HTsitelist{i,1} '.Properties.UserData{1},'' Site Standard Error of the Mean '',' HTsitelist{i,1} '.Properties.Description];']);
        eval(['semTable.Properties.VariableUnits = ' HTsitelist{i,1} '.Properties.VariableUnits([1,3,7]);']);
        eval(['semTable.Properties.VariableNames = ' HTsitelist{i,1} '.Properties.VariableNames([1,3,7]);']);
        semTable.Properties.UserData = {'DS1923'};
        eval(['SSEM' nameparts{1} '_' num2str(HTsitenum{i,1}) '_' nameparts{3} ' = semTable;']);
        eval(['save(ASEMfile,''SSEM' nameparts{1} '_' num2str(HTsitenum{i,1}) '_' nameparts{3} ''',''-append'')']);
        s = 1;
    end
    toc
end
if ~isempty(Leftovers)
    if eval(['exist(''iButtonALeftovers_' Tdate '.mat'',''file'')']) == 0
        eval(['ALfile = ''iButtonALeftovers_' Tdate '.mat'';']);
        eval(['Leftovers{r,1} = ''Found in iButtonALeftovers_' Tdate '.mat'';']);
    else
        if strcmp(writeover,'y')
            eval(['ALfile = ''iButtonALeftovers_' Tdate '.mat'';']);
            eval(['Leftovers{r,1} = ''Found in iButtonALeftovers_' Tdate '.mat'';']);
        else
            eval(['ALfile = ''iButtonALeftovers_' Tdate '_' num2str(datenum(Tstamp)) '.mat'';']);
            eval(['Leftovers{r,1} = ''Found in iButtonALeftovers_' Tdate '_' num2str(datenum(Tstamp)) '.mat'';']);
        end
    end
    save(ALfile,'Tstamp');
    for p = 1:r-1
        eval(['save(ALfile,''' Leftovers{p,1} ''',''-append'')']);
    end
    eval(['disp(''' num2str(r-1) ' data tables were not processed.'')']);
    save(Afile,'Leftovers','-append')
end
disp('complete');
% [*]