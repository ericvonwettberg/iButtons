function [ outputArray ] = tableList( filename,format )
%TABLELIST generates a list of variables from a .mat file
%   Takes a file name, string or cell array of strings, and searches for
%   variables that match the format(s) [string or cell array of strings]. 
% Written by EDC 2015 (20150410)
if ischar(filename)
    filename = cellstr(filename);
end
if ischar(format)
    format = cellstr(format);
end
if numel(filename) ~= numel(format)
    disp('The number of formats and the number of files must be equal.')
    return
end
vlist = cell(numel(filename),1);
% Perform search
for i = 1:numel(filename)
    if iscell(format{i})
        formatnum = numel(format{i});
        sublist = cell(formatnum,1);
    else
        formatnum = 1;
    end
    for j = 1:formatnum
        varlist = who('-file',filename{i});
        varsearch = regexp(varlist,format{i});
        checke = cellfun(@isempty,varsearch);
        newvarlist = varlist(~checke);
        if formatnum ~= 1
            sublist(j,1) = {newvarlist};
        end
    end
    if formatnum == 1
        vlist(i,1) = {newvarlist};
    else
        vlist(i,1) = {sublist};
    end
end
% Output list(s)
if numel(filename) == 1
    outputArray = vlist{:};
else
    outputArray = vlist;
end
end
% [*]