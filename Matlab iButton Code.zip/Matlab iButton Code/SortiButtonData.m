%% SortiButtonData:
% Reads .mat iButton data files and creates a data file
% with data sorted by time of day.
% Written by EDC 2015 (20150317)
fprintf('Welcome to the Sort iButton Data Program\nThis program will sort iButton sensor data tables into four groups, according to the time of day.\n');
ready = input('Ready to begin? (y/n)','s'); %Allows user to exit program
if ~strcmp(ready,'y')
    return
end
% Allows users to select multiple files from a folder, constrained to .csv
% files
fprintf('The data file should have the following naming scheme "iButton[type]Data_[date].mat".\nPlease select the iButton data table files you would like to sort.\n');
[FileName,PathName,FilterIndex] = uigetfile('*.mat','Select iButton Data Set','MultiSelect','on');
if FilterIndex == 0
    return %If no files selected program exits
end
if ~iscell(FileName)
    FileName = {FileName};
end
disp(['Number of files selected: ',num2str(numel(FileName))]);
% Inform user that DS1923 data will not be sorted seperately, by default
disp('This program is set to only interpret DS1921G data individually, DS1923 must be in corrected format (HT table).');
% Allow for user to change that.
% Save file created
Tstamp = clock; % Timestamp
Tdate = datestr(date);
if eval(['exist(''iButtonSData_' Tdate '.mat'',''file'')']) == 0
    eval(['Sfile = ''iButtonSData_' Tdate '.mat'';']);
else
    eval(['disp([''The output file: "iButtonSData' Tdate '.mat" already exists.'']);']);
    writeover = input('Write over existing file? (y/n)','s');
    if strcmp(writeover,'y')
        eval(['Sfile = ''iButtonSData_' Tdate '.mat'';']);
        disp('File will be overwritten.');
    else
        disp('File will not be written over. A new file will be created');
        eval(['Sfile = ''iButtonSData_' Tdate '_' num2str(datenum(Tstamp)) '.mat'';']);
    end
end
save(Sfile,'Tstamp');
% Create and load table lists
for i = 1:numel(FileName)
    if strncmp('iButtonHTData',FileName{i},12)
        HTlist = tableList(FileName{i},'HT_\d*_\d*[ci]');
        eval(['load(''' PathName FileName{i} ''',HTlist{:});']);
    elseif strncmp('iButtonTData',FileName{i},12)
        Tlist = tableList(FileName{i},'T_\d*_\d*[ci]');
        eval(['load(''' PathName FileName{i} ''',Tlist{:});']);
        checkdt = false(size(Tlist,1),1);
        for j = 1:size(Tlist,1)
            eval(['checkdt(j) = strcmp(' Tlist{j,1} '.Properties.UserData{3},''DS1921G'');'])
        end
        Tlist = Tlist(checkdt);
    elseif strncmp('iButtonAData',FileName{i},12)
        ATlist = tableList(FileName{i},'AT_\d*_\d*[ci]');
        AHTlist = tableList(FileName{i},'AHT_\d*_\d*[ci]');
        eval(['load(''' PathName FileName{i} ''',ATlist{:},AHTlist{:});']);
    end
end
lists = {Tlist,HTlist,ATlist,AHTlist};
if exist('minmax','var') && strncmp('iButtonAMData',FileName{i},12)
    MinTlist = tableList(FileName{i},'MinT_\d*_\d*[ci]');
    eval(['load(''' PathName FileName{i} ''',MinTlist{:});']);
    MaxTlist = tableList(FileName{i},'MaxT_\d*_\d*[ci]');
    eval(['load(''' PathName FileName{i} ''',MaxTlist{:});']);
    MinHTlist = tableList(FileName{i},'MinHT_\d*_\d*[ci]');
    eval(['load(''' PathName FileName{i} ''',MinHTlist{:});']);
    MaxHTlist = tableList(FileName{i},'MaxHT_\d*_\d*[ci]');
    eval(['load(''' PathName FileName{i} ''',MaxHTlist{:});']);
    lists = {MinTlist,MaxTlist,MinHTlist,MaxHTlist};
end
% Ask about SEM processing
processSEM = input('Process SEM Tables? (y/n)','s');
if strcmp(processSEM,'y')
    wsvarlist3b
end
% Ask for time-of-day trasition times
prompt = {'Daytime hours start:','Daytime hours end:','Nighttime hours start:','Nighttime hours end:'};
defAns = {'9:55','16:00','21:55','4:00'};
answer = inputdlg(prompt,'Set Time Parameters (24Hr Format)',1,defAns);
%% Sort Tables
for i = 1:4
    if ~isempty(lists{i})
        fprintf('Processing list %d of 4...\n',i);
        for j = 1:size(lists{i},1)
            if isempty(lists{i}{j,1})
                continue
            end
            name = lists{i}{j,1};
            np = find(name=='_',1,'first');
            eval([name(1:np-1) 'S' name(np:end) ' = iDataTimeSort(' lists{i}{j,1} ',answer);'])
            eval(['save(Sfile,''' name(1:np-1) 'S' name(np:end) ''',''-append'')']);
            if size(lists{i},2) > 1 && strcmp(processSEM,'y') && ~isempty(lists{i}{j,2})
                nameparts = strsplit(lists{i}{j,2},'_');
                eval([name(1:np-1) 'S' name(np:end) ' = iDataTimeSort(' lists{i}{j,2} ',answer);'])
                eval(['save(Sfile,''' name(1:np-1) 'S' name(np:end) ''',''-append'')']);
            end
        end
    else
        fprintf('Skipping list %d of 4...\n',i);
    end
end
disp('Complete.');
% [*]