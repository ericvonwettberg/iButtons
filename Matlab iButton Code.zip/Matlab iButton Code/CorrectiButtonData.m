%% CorrectiButtonData:
% Reads .mat iButton data files and creates a data file with corrections for DS1923 devices.
% Written by EDC 2014 (20150411)
fprintf('Welcome to the Correct iButton Data Program\nThis program will correct iButton sensor data tables from Hygrochron (DS1923) sensors.\n');
ready = input('Ready to begin? (y/n)','s'); %Allows user to exit program
if ~strcmp(ready,'y')
    return
end
% Allows users to select multiple files from a folder, constrained to .csv
% files
fprintf('The data file should have the following naming scheme "iButton[type]Data_[date].mat".\nPlease select the iButton data table files you would like to merge and correct.\n');
[FileName,PathName,FilterIndex] = uigetfile('*.mat','Select iButton Data Set','MultiSelect','on');
if FilterIndex == 0
    return %If no files selected program exits
end
if ~iscell(FileName)
    FileName = {FileName};
end
disp(['Number of files selected: ',num2str(numel(FileName))]);
% Make sure the two files were created on the same date and that there is
% one of each type, humidity and temperature.
sep1 = strsplit(FileName{1},{'_','.'});
sep2 = strsplit(FileName{2},{'_','.'});
if strcmp(sep1{1},sep2{1})
    disp('Both humidity and temperature data table files must be used!');
    return
elseif ~strcmp(sep1{2},sep2{2})
    disp('Both humidity and temperature data table files must be have the same timestamp!');
    return
end
% User input of calibration standards file
disp('Please select a calibration standards file (of type .csv)');
[FileName2,PathName2,FilterIndex2] = uigetfile('*.csv','Select Calibration Standard File');
if FilterIndex2 == 0
    return %If no files selected program exits
end
% Create and load table lists
for i = 1:numel(FileName)
    if strncmp('iButtonHData',FileName{i},12)
        Hlist = tableList(FileName{i},'H_DS\d*_\w*_\d*[ci]');
        eval(['load(''' PathName FileName{i} ''',Hlist{:});']);
        Hlist(end,3) = {[]};
    elseif strncmp('iButtonTData',FileName{i},12)
        Tlist = tableList(FileName{i},'T_DS\d*_\w*_\d*[ci]');
        eval(['load(''' PathName FileName{i} ''',Tlist{:});']);
        Tlist(end,2) = {[]};
    end
end
try
    eval(['[Site,Location,Sensor,DeviceAddress,CalStands,HTStandard] = importstandards(''' PathName2 FileName2 ''');']);
catch
    eval(['[Site,Location,Sensor,DeviceAddress,CalStands] = importstandards2(''' PathName2 FileName2 ''');']);
end
% Pair temperature and humidity data from the same device and timespan
for i = 1:size(Hlist,1)
    if isempty(Hlist{i,1})
        break
    end
    Hinfo = strsplit(Hlist{i,1},'_'); % Device address now in matrix name
    HAddy = Hinfo{1,3};
    HYear = Hinfo{1,4};
    for j = 1:size(Tlist,1)
        if isempty(Tlist{j,2})
            Tinfo = strsplit(Tlist{j,1},'_');
            TAddy = Tinfo{1,3};
            TYear = Tinfo{1,4};
            if strcmp(HAddy,TAddy) && strcmp(HYear,TYear)
                Hlist{i,2} = Tlist{j,1};
                Tlist{j,2} = 'Paired';
                break
            end
        end
    end
    for k = 1:size(DeviceAddress,1)
        if strcmp(HAddy,DeviceAddress{k,1})
            Hlist{i,3} = k;
            break
        end
    end
end
%% Save file created
Tstamp = clock; % Timestamp
Tdate = datestr(date);
if eval(['exist(''iButtonHTData_' Tdate '.mat'',''file'')']) == 0
    eval(['HTfile = ''iButtonHTData_' Tdate '.mat'';']);
else
    eval(['disp([''The output file: "iButtonHTData' Tdate '.mat" already exists.'']);']);
    writeover = input('Write over existing file? (y/n)','s');
    if strcmp(writeover,'y')
        eval(['HTfile = ''iButtonHTData_' Tdate '.mat'';']);
        disp('File will be overwritten.');
    else
        disp('File will not be written over. A new file will be created');
        eval(['HTfile = ''iButtonHTData_' Tdate '_' num2str(datenum(Tstamp)) '.mat'';']);
    end
end
save(HTfile,'Tstamp');
save(HTfile,'Hlist','-append');
%% Data Correction
% Temperature correction, Humidity correction -> Temperature compensation
% -> Saturation Drift compensation
HTlabels = ['temp', 'tcorr', 'humidity', 'hcorr', 'htcomp', 'hsdcomp'];
Leftovers = cell(5,0);
m = 1;
for i = 1:size(Hlist,1)
    tic
    if isempty(Hlist{i,1})
        continue
    elseif isempty(Hlist{i,2})
        Leftovers{m,1} = Hlist{i,1};
        m = m + 1;
        eval(['disp(''' Hlist{i,1} ' skipped.'');']);
        continue
    else
        eval(['disp(''Processing ' Hlist{i,1} '...'');']);
        % Temperature Correction
        eval(['tcorr = tempcorrection(' Hlist{i,2} '(:,3),CalStands{' num2str(Hlist{i,3}) ',1});']);
        % Humidity Correction
        eval(['hcorr = humiditycorrection(' Hlist{i,1} '(:,3),CalStands{' num2str(Hlist{i,3}) ',1});']);
        % Temperature Compensation
        htcomp = tempcompensation(tcorr,hcorr);
        % Saturation Drift Compensation (Includes removal of negative
        % values and round to 3 decimal places) **
        hsdcomp = saturationdrift(tcorr,htcomp);
        hsdcomp = round(hsdcomp*1000)/1000;
        tcorr = round(tcorr*1000)/1000;
        % Create new data table
        eval(['HT_' Hlist{i,1}(3:end) ' = [' Hlist{i,1} '(:,1),' Hlist{i,2} '(:,3), tcorr, ' Hlist{i,1} '(:,3), hcorr, htcomp, hsdcomp];']);
        eval(['save(HTfile,''HT_' Hlist{i,1}(3:end) ''',''-append'')']);
    end
    toc
end
if ~isempty(Leftovers)
    eval(['disp(''' num2str(m-1) ' data tables were not processed.'')']);
end
disp('complete');
%% Export data
% Export as xls file
% [*]