%% DetermineIntervalAverages
% Reads .mat iButton data files and creates a data file
% with data averaged into daily, weekly and monthly from all site sensor data.
% DS1921G and DS1923 data is averaged separately.
% It can accepts sorted data, either in site-averaged and non-averaged form.
% Written by EDC 2015 (20150130)
fprintf('Welcome to the Interval Average iButton Data Program\nThis program will create interval averages from sorted iButton sensor data tables.\nNote: Thermochron and Hygrochron temperature data are averaged separately.\n');
ready = input('Ready to begin? (y/n)','s'); %Allows user to exit program
if ~strcmp(ready,'y')
    return
end
% Allows users to select multiple files from a folder, constrained to .csv
% files
fprintf('The data file should have the following naming scheme "iButtonSData_[date].mat".\nPlease select the iButton data table files you would like to average.\n');
[FileName,PathName,FilterIndex] = uigetfile('*.mat','Select iButton Data Set','MultiSelect','on');
if FilterIndex == 0
    return %If no files selected program exits
end
if ~iscell(FileName)
    FileName = {FileName};
end
disp(['Number of files selected: ',num2str(numel(FileName))]);
% Create and load table lists
for i = 1:numel(FileName)
    if strncmp('iButtonSData',FileName{i},12)
        TSlist = tableList(FileName{i},'TS_\d*_\d*[ci]');
        HTSlist = tableList(FileName{i},'HTS_\d*_\d*[ci]');
        ATSlist = tableList(FileName{i},'ATS_\d*_\d*[ci]');
        AHTSlist = tableList(FileName{i},'HTS_\d*_\d*[ci]');
        eval(['load(''' PathName FileName{i} ''',TSlist{:},HTSlist{:},ATSlist{:},AHTSlist{:});']);
    end
end
wsvarlist4b
% Inform user that DS1923 data will not be sorted seperately, by default
disp('This program is set to only interpret DS1921G data separately, DS1923 must be in corrected format (HTS or AHTS table).');
% Save file created
Tstamp = clock; % Timestamp
Tdate = datestr(date);
if eval(['exist(''iButtonIData_' Tdate '.mat'',''file'')']) == 0
    eval(['Ifile = ''iButtonIData_' Tdate '.mat'';']);
    eval(['ISEMMfile = ''iButtonISEMMData_' Tdate '.mat'';']);
else
    eval(['disp([''The output file: "iButtonIData' Tdate '.mat" already exists.'']);']);
    writeover = input('Write over existing file? (y/n)','s');
    if strcmp(writeover,'y')
        eval(['Ifile = ''iButtonIData_' Tdate '.mat'';']);
        eval(['ISEMMfile = ''iButtonISEMMData_' Tdate '.mat'';']);
        disp('Files will be overwritten.');
    else
        disp('Files will not be written over. A new file will be created');
        eval(['Ifile = ''iButtonIData_' Tdate '_' num2str(datenum(Tstamp)) '.mat'';']);
        eval(['ISEMMfile = ''iButtonISEMMData_' Tdate '_' num2str(datenum(Tstamp)) '.mat'';']);
    end
end
save(Ifile,'Tstamp');
disp('Daily, weekly and monthly interval average tables will be generated seperately.');
%% Perform Daily Averages
lists = {TSlist,HTSlist,ATSlist,AHTSlist};
if exist('minmax','var')
    wsvarlist8
    lists = {MinTSlist,MaxTSlist,MinHTSlist,MaxHTSlist};
    clear SEMlist
end
intlabels = ['D';'M';'W'];
for i = 1:4
    tic
    if ~isempty(lists{i})
        tcount =find(~cellfun('isempty',lists{i}));
        fprintf('Processing list %d of 4: Containing %d table(s)...\n',i,numel(tcount));
        for j = 1:size(lists{i},1)
            if i > 2 && ~isempty(lists{i}{j,2})
                SEMM = true;
            else
                SEMM = false;
            end
            if isempty(lists{i}{j,1})
                continue
            end
            for jj = 1:3
                eval(['[' intlabels(jj,:) lists{i}{j,1} ',' intlabels(jj,:) 'ISEM' lists{i}{j,1} '] = intervalaverage(' lists{i}{j,1} ',''' intlabels(jj,:) ''',true);'])
                if SEMM
                    tagstart = strfind(lists{i}{j,2},'SEM');
                    tag = lists{i}{j,2}(tagstart+3:end);
                    eval([intlabels(jj,:) 'SEMM' tag ' = intervalSEMM(' lists{i}{j,2} ',''' intlabels(jj,:) ''');'])
                    eval(['save(ISEMMfile,''' intlabels(jj,:) 'SEMM' tag ''',''-append'')']);
                end
                eval(['save(Ifile,''' intlabels(jj,:) lists{i}{j,1} ''',''' intlabels(jj,:) 'ISEM' lists{i}{j,1} ''',''-append'')']);
            end
        end
    else
        fprintf('Skipping list %d of 4...\n',i);
    end
    toc
end
disp('Complete.');
% [*]