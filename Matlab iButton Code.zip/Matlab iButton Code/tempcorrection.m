function [ corrMatrix ] = tempcorrection( tempMatrix, standards )
%TEMPCORRECTION accepts iButton temperature array and calibration standards then outputs
%an array of corrected temperatures.
%   tempcorrection applies the iButton internal calibration standards to
%   generate corrected temperatures. Temperatures will be corrected
%   according to the methods created by Maxim and listed in the DS1923
%   iButton product manual. The function accepts an array of temperatures
%   (type double) and a calibration standard string (8 or 16 hexadecimal
%   pairs; e.g. 00 00 00 00 00 00 00 00). The output is an array of
%   corrected temperatures (type double).
%
%   function format: Tcorrected = tempcorrection( tempArray, standards );

if nargin < 2
    msgID = 'ERRFUN:MissingArgs';
    msg = 'Function requires more input. Please use the following format: tempcorrection( tempArray, standards )';
    baseException = MException(msgID,msg);
    throw(baseException)
end

Temps = tempMatrix;
CalibStand = strsplit(standards);
StandTitles = {'Tr2H','Tr2L','Tc2H','Tc2L','Tr3H','Tr3L','Tc3H','Tc3L'};
% Retrieve and convert binary standard segments
for i = 1:8
    eval([StandTitles{i} ' = ' num2str(hex2dec(CalibStand(i))) ';']);
end
% Preparation of correction values using method as reported by Maxim in the
% DS1923 iButton data sheet.
%
% Create unlisted standards
Tr1 = 60;
Offset = 41;
% Calculate standard values from standard segments
Tr2 = Tr2H/2 + Tr2L/512 - Offset;
Tr3 = Tr3H/2 + Tr3L/512 - Offset;
Tc2 = Tc2H/2 + Tc2L/512 - Offset;
Tc3 = Tc3H/2 + Tc3L/512 - Offset;
% Determine error
TErr2 = Tc2 - Tr2;
TErr3 = Tc3 - Tr3;
TErr1 = TErr2;
% Calculate correction factors
B = ((Tr2^2-Tr1^2)*(TErr3-TErr1)/((Tr2^2-Tr1^2)*(Tr3-Tr1)+(Tr3^2-Tr1^2)*(Tr1-Tr2)));
A = (B*(Tr1-Tr2)/(Tr2^2-Tr1^2));
C = (TErr1 - A*Tr1^2 - B*Tr1);

%   Execution of correction
corrMatrix = Temps - (A*Temps.^2 + B*Temps + C);

end

% [*]