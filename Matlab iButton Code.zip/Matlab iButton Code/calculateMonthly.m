function [ outputArray, outputSEM ] = calculateMonthly( inputArray, nightStart, nightEnd )
%CALCULATEMONTHLY
%   Performs the averaging calculation for data at monthly intevals.
%   Requires a cell array with a date/times column and value column(s).
%   Both T and HT data is accepted. Input of two strings can be used to
%   adjust the hours for nighttime readings. (Default: Start-21:55, End-
%   4:00) Also calculates the Standard Error of the Mean.
% Written by EDC 2015 (20150319)
if nargin == 1
    nTime = ['21:55';'04:00'];
elseif nargin == 3
    nTime = [nightStart;nightEnd];
else
    disp('Function requires input of one cell type data array and/or one cell type data array and two strings for night start and end times!');
    return
end
if ~iscell(inputArray)
    disp('Function requires input of cell type data array!');
    return
elseif size(inputArray,2) ~= 3
    fprintf('Data array should contain 3 columns!\n[DateTime][Unit][Value] or [DateTime][Value][Value]');
    return
end
nvec = datevec(nTime,'HH:MM');
DateTimes = char(inputArray{:,1});
Dates = datevec(DateTimes,'dd-mmm-yyyy HH:MM:SS');
dataType = ischar(inputArray{1,2});
values1 = [inputArray{:,2}]';
values2 = [inputArray{:,3}]';
ss = ((size(DateTimes,1)-mod(size(DateTimes,1),60))/60);
intervalAvg = cell(ss,3);
intervalSEM = nan(ss,3);
% Check for nighttime data
checkS = Dates(1,:) >= nvec(1,:);
checkE = Dates(1,:) <= nvec(2,:);
if checkS(1,4) == 1
    if Dates(1,4) == nvec(1,4)
        if checkS(1,5) == 1
            night = 1;
        else
            night = 0;
        end
    else
        night = 1;
    end
elseif checkE(1,4) == 1
    if Dates(1,4) == nvec(2,4)
        if checkE(1,5) == 1
            night = 1;
        else
            night = 0;
        end
    else
        night = 1;
    end
else
    night = 0;
end
%% Perform Monthly Average Calculation
t = 1;
r = 1;
%ll = 0;
while r <= size(Dates,1)
    %ll = ll + 1;
    %fprintf('Iteration %d\n',ll);
    Month = [Dates(r,1:2) 1 0 0 0];
    intervalAvg{t,1} = datestr(Month,'yyyy-mmm');
    intervalSEM(t,1) = datenum(Month);
    tD = [Dates(r,1:2) 1 0 0 0] + [0 1 0 0 0 0];
    tDstr = datestr(tD,0);
    testDate = datevec(tDstr,0);
    if dataType == 1
        intervalAvg{t,2} = values1(r,:);
        intervalAvg{t,3} = values2(r);
    else
        intervalAvg{t,2} = values1(r);
        intervalAvg{t,3} = values2(r);
    end
    if r == size(Dates,1)
        break
    elseif sum(Dates(r,1:2) == Dates(r+1,1:2)) ~= 2
        if Dates(r,4) > nvec(1,4) - 1
            ndcheck = sum(testDate(1:3) == Dates(r+1,1:3));
        else
            ndcheck = 0;
        end
        if night == 0 || ndcheck ~= 3 || Dates(r+1,4) > nvec(2,4) + 1
            t = t + 1;
            r = r + 1;
            continue
        end
    end
    ncheck = 0;
    for s = r+1:size(Dates,1)
        mcheck = sum(Dates(r,1:2) == Dates(s,1:2)) == 2;
        newdcheck = sum(Dates(s,1:3) == testDate(1:3)) == 3;
        if night == 1 && mcheck == 1 % Checks: Night,Same month
            ncheck = 1;
        elseif night == 1 && newdcheck == 1 && Dates(s,4) < nvec(2,4) + 1 % Checks: Night,1st day of next month,Pre-dawn hours
            ncheck = 1;
        else
            ncheck = 0;
        end
        if (night == 0 && mcheck == 1) || (night == 1 && ncheck == 1)
            if dataType == 1
                intervalAvg{t,3} = intervalAvg{t,3} + values2(s);
            else
                intervalAvg{t,2} = intervalAvg{t,2} + values1(s);
                intervalAvg{t,3} = intervalAvg{t,3} + values2(s);
            end
        else
            if dataType == 1
                intervalAvg{t,3} = intervalAvg{t,3}/(s-r);
                intervalSEM(t,3) = nanstd(values2(r:s))/sqrt(s-r-sum(isnan(values2(r:s))));
            else
                intervalAvg{t,2} = intervalAvg{t,2}/(s-r);
                intervalAvg{t,3} = intervalAvg{t,3}/(s-r);
                intervalSEM(t,2) = nanstd(values1(r:s))/sqrt(s-r-sum(isnan(values1(r:s))));
                intervalSEM(t,3) = nanstd(values2(r:s))/sqrt(s-r-sum(isnan(values2(r:s))));
            end
            t = t + 1;
            r = s;
            break
        end
        if  s == size(Dates,1)
            if dataType == 1
                intervalAvg{t,3} = intervalAvg{t,3}/((s+1)-r);
                intervalSEM(t,3) = nanstd(values2(r:s))/sqrt(s+1-r-sum(isnan(values2(r:s))));
            else
                intervalAvg{t,2} = intervalAvg{t,2}/((s+1)-r);
                intervalAvg{t,3} = intervalAvg{t,3}/((s+1)-r);
                intervalSEM(t,2) = nanstd(values1(r:s))/sqrt(s+1-r-sum(isnan(values1(r:s))));
                intervalSEM(t,3) = nanstd(values2(r:s))/sqrt(s+1-r-sum(isnan(values2(r:s))));
            end
            r = s + 1;
            break
        end
    end
end
SEMarray = cellstr(datestr(intervalSEM(:,1)));
if dataType == 1
    SEMarray(:,2) = {values1(1,:)};
else
    SEMarray(:,2) = num2cell(intervalSEM(:,2));
end
SEMarray(:,3) = num2cell(intervalSEM(:,3));
%% Output new array
outputArray = intervalAvg;
outputSEM = SEMarray;
end
% [*]