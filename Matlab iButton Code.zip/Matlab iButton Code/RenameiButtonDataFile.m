%RenameiButtonDataFile
% Written by EDC 2015 (20150409)
sensorfile = 'Sensors_E.mat';
[FileName,PathName,FilterIndex] = uigetfile('*.csv','Select iButton Data','MultiSelect','on');
if FilterIndex == 0
    return %If no files selected program exits
end
if ischar(FileName)
    FileName = {FileName};
end
numF = size(FileName,2); %Number of files selected
disp(['Number of files selected: ',num2str(numF)]);
load(sensorfile)
sensorList = who('-file',sensorfile);
% Get info from files
SensorInfo = cell(numF,3);
skipped = 0;
for i = 1:numF
    fname = strcat(PathName,FileName{1,i});
    fid = fopen(fname,'r');
    [check,device,address,data] = deal(false);
    while ~check && (~feof(fid))
        line = fgetl(fid);
        if ~device && ~isempty(strfind(line,'Part Number:'))
            p = strfind(line,'DS');
            line = line(p:p+5);
            SensorInfo{i,1} = line;
            device = true;
        elseif ~address && ~isempty(strfind(line,'Registration Number:'))
            p = strfind(line,':');
            line = line(p+2:end);
            SensorInfo{i,2} = line;
            address = true;
        elseif strncmp('Date/Time',line,9)
            line = fgetl(fid);
            parts = strsplit(line,',');
            SensorInfo(i,3) = parts(2);
            data = true;
        end
        check = device && address && data;
    end
    if feof(fid)
        SensorInfo(i,3) = {[]};
        fprintf('Necessary information not found, skipping file:\n %s\n',FileName{1,i})
    end
    fclose(fid);
end
% Use file info to generate new name
for i = 1:size(SensorInfo,1)
    if isempty(SensorInfo{i,1})
        continue
    end
    % Determine size of sensor array
    sensorLocation = strcmp(SensorInfo{i,1},sensorList);
    sensorLoc = find(sensorLocation,1,'first');
    if isempty(sensorLoc)
        fprintf('Sensor list for device model %s was not found. File %s will not be renamed.\n',SensorInfo{i,1},FileName{1,i})
        continue
    end
    eval(['k = size(' sensorList{sensorLoc} ',2);'])
    eval(['locate = strcmp(SensorInfo{i,2},' SensorInfo{i,1} '(:,k));'])
    loc = find(locate,1,'first');
    if isempty(loc)
        fprintf('Device %s was not found. File %s will not be renamed.\n',SensorInfo{i,2},FileName{1,i})
        continue
    end
    if strcmp(SensorInfo{i,3},'C')
        if eval([SensorInfo{i,1} '{loc,k-1} > 1'])
            eval(['datatype = [''temp'',num2str(' SensorInfo{i,1} '{loc,k-1})];'])
        else
            datatype = 'temp';
        end
    elseif strcmp(SensorInfo{i,3},'%RH')
        if eval([SensorInfo{i,1} '{loc,k-1} > 1'])
            eval(['datatype = [''humidity'',num2str(' SensorInfo{i,1} '{loc,k-1})];'])
        else
            datatype = 'humidity';
        end
    else
        fprintf('Data type for device %s was not recognized. File %s will not be renamed.\n',SensorInfo{i,2},FileName{1,i+skipped})
        continue
    end
    if k == 4
        eval(['FileName{2,i} = [' SensorInfo{i,1} '{loc,1},''_'',num2str(' SensorInfo{i,1} '{loc,2}),''_'',datatype,''.csv''];'])
    else
        eval(['FileName{2,i} = [' SensorInfo{i,1} '{loc,1},''_1_'',datatype,''.csv''];'])
    end
end
Status = cell(numF,1);
Msg = cell(numF,1);
for i = 1:size(FileName,2)
    if size(FileName,1) == 1
        break
    elseif isempty(FileName{2,i}) || strcmp(FileName{1,i},FileName{2,i})
        continue
    end
    Source = strcat(PathName,FileName{1,i});
    Dest = strcat(PathName,FileName{2,i});
    [Status{i,1},Msg{i,1}] = FileRename(Source, Dest,'DoNotOverwrite');
end
disp('Complete.')
% [*]