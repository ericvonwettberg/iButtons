%% LoadiButtonData: Reads iButton raw data files and creates tables saved
% to a data file.
% Written by EDC 2014 (2015_01_06)
disp('Welcome to the Load iButton Data Program');
ready = input('Would you like to create a new project? (y/n)','s'); %Allows user to exit program
if strcmpi(ready,'y')
    Pname = input('Please enter a name for the new project.','s');
    parentFolder = uigetdir('D:\iButton Data','Select Project Save Location');
    newPFolder = [parentfolder,'\',Pname];
if ~exist(newPFolder, 'dir')
  mkdir(newPFolder);
else
    
end
elseif strcmpi(ready,'n')
    %folder_name = uigetdir(start_path);
else
    return
end

% Units
TUnit = 'C';
HUnit = '%RH';

[SFileName,SPathName,SFilterIndex] = uigetfile('*.mat','Select iButton Sensor ID Set');
if SFilterIndex == 0
    return %If no files selected program exits
end
% Allows users to select multiple files from a folder, constrained to .csv
% files
fprintf('This program will load iButton sensor data files with a ".csv" file extension.\nPlease select the iButton data files you would like to merge.\n');
[FileName,PathName,FilterIndex] = uigetfile('*.csv','Select iButton Data','MultiSelect','on');
if FilterIndex == 0
    return %If no files selected program exits
end
if ischar(FileName)
        FileName = {FileName};
end
numF = size(FileName,2); %Number of files selected
disp(['Number of files selected: ',num2str(numF)]);
load(SFileName)
% Get info from files
SensorInfo = cell(numF,3);
skipped = 0;
for i = 1:numF
    fname = strcat(PathName,FileName{1,i});
    fid = fopen(fname,'r');
    [check,device,address,data] = deal(false);
    while ~check && (~feof(fid))
        line = fgetl(fid);
        if ~device && ~isempty(strfind(line,'Part Number:'))
            p = strfind(line,'DS');
            line = line(p:p+5);
            SensorInfo{i,1} = line;
            device = true;
        elseif ~address && ~isempty(strfind(line,'Registration Number:'))
            p = strfind(line,':');
            line = line(p+2:end);
            SensorInfo{i,2} = line;
            address = true;
        elseif strncmp('Date/Time',line,9)
            line = fgetl(fid);
            parts = strsplit(line,',');
            SensorInfo(i,3) = parts(2);
            data = true;
        end
        check = device && address && data;
    end
    if feof(fid)
        SensorInfo(i,3) = {[]};
        fprintf('Necessary information not found, skipping file:\n %s\n',FileName{1,i})
    end
    fclose(fid);
end
% Separates temperature and humidity files to be processed. Creates a list
% of Site, Location and Sensor titles for reformatting of data to be imported.
t = 1; %temp file counter
h = 1; %humidity file counter
partsT = cell(1,5);
partsH = cell(1,5);

for j = 1:numF
    sep = strsplit(FileName{j},{'_','.'});
    if ~strcmp(sep{4},'csv')
        disp(['File name error; file ',num2str(j),': ',FileName{j}])
        return
    end
    if strcmp(sep{3}(1:4), 'temp')
        if ~strcmp(sep{3},'temp')
            sep{3} = sep{3}(5:end);
        else
            sep{3} = '1';
        end
        partsT(t,1:4) = sep;
        partsT(t,5) = {j};
        t = t+1;
    elseif strcmp(sep{3}(1:8), 'humidity')
        if ~strcmp(sep{3},'humidity')
            sep{3} = sep{3}(9:end);
        else
            sep{3} = '1';
        end
        partsH(h,1:4) = sep;
        partsH(h,5) = {j};
        h = h+1;
    else
        disp(['File name error; file ',num2str(j),': ',FileName{j}])
        return
    end
end

% Number of files to be processed
numT = num2str(t-1);
numH = num2str(h-1);
disp(['Number of temperature files: ',numT]);
disp(['Number of humidity files: ',numH]);
% User selects data to be merged
mergeD = input('Load both temperature and humidity data? (y/n)', 's');
if strcmp(mergeD,'y')
    mergeT = 'y';
    mergeH = 'y';
else
    mergeT = input('Load temperature data? (y/n)', 's');
    mergeH = 'n';
    if ~strcmp(mergeT,'y')
        mergeH = input('Load humidity data? (y/n)', 's');
    end
end
% User inputs Time Zone correction factor if necessary (& avail.)
if exist('performTZcorrection.m','file') > 0
    correctD = input('Perform correction for time zone? (y/n)', 's');
    correctD = validatestring(correctD,{'y','n'});
    if strcmp(correctD,'y')
        corrTZ = performTZcorrection(); % Creates a correction value corrTZ
    end
else
    correctD = 'n';
end
% Choose data splitting method
askmethod = input('Input table splitting method: "Standard" or "ToD"\nStandard: Uses the standard end of day, midnight\nToD: Uses the night setting for end of day\nDefault setting is Standard.','s'); %Allows user to exit program
if ~isempty(askmethod)
    method = validatestring(askmethod,{'Standard','ToD'});
else
    method = 'Standard';
end

Tstamp = clock; % Timestamps
Tdate = datestr(date);

%% If applicable, temperature data is imported, reformatted and saved
if strcmp(mergeT,'y') && t > 1
    % Create save file for data
    if eval(['exist(''iButtonTData_' Tdate '.mat'',''file'')']) == 0
        eval(['Tfile = ''iButtonTData_' Tdate '.mat'';']);
    else
        eval(['disp([''The output file: "iButtonTData' Tdate '.mat" already exists.'']);']);
        writeover = input('Write over existing file? (y/n)','s');
        if strcmp(writeover,'y')
            eval(['Tfile = ''iButtonTData_' Tdate '.mat'';']);
            disp('File will be overwritten.');
        else
            disp('File will not be written over. A new file will be created');
            eval(['Tfile = ''iButtonTData_' Tdate '_' num2str(datenum(Tstamp)) '.mat'';']);
        end
    end
    save(Tfile,'Tstamp');
    % Import data to table and save table to file
    TAdds = cell(length(partsT),1);
    for k = 1:(t-1)
        n = partsT{k,5};
        % Importing data and creating the data arrays for the table
        % Categorical arrays used when possible to reduce space used
        StartLine = detLine(strcat(PathName,FileName{n})); % Data starting point
        [deviceType, deviceAddress] = deviceinfo(strcat(PathName,FileName{n}),1,2); % Device physical address
        TAdds{k} = deviceAddress;
        DUVmatrix = importifile(strcat(PathName,FileName{n}),TUnit,StartLine);
        if strcmp(correctD,'y')
            DUVmatrix(:,1) = DUVmatrix(:,1) + corrTZ;
        end
        tLim = tableLimits(DUVmatrix(:,1),method,true);
        for i = 1:size(tLim,1)
            if i == size(tLim,1)
                if tLim(i,2) == size(DUVmatrix,1)
                    break %If only one entry exist then no separate tables are created
                end
                last = size(DUVmatrix,1);
            else
                last = tLim(i+1,2)-1;
            end
            [Y,M] = datevec(tLim(i,1));
            if tLim(i,3) == 1
                comp = 'c';
            else
                comp = 'i';
            end
            yrs = [num2str(Y-2000),num2str(Y-1999),comp];
            eval(['Mname = ''T_' deviceType '_' deviceAddress '_' yrs ''';'])
            eval([Mname ' = DUVmatrix(tLim(i,2):last,:);'])
            eval(['save(Tfile,''' Mname ''',''-append'')'])
        end
    end
end

%% If applicable, humidity data is imported and reformatted
if strcmp(mergeH,'y') && h > 1
    % Create save file for data
    if eval(['exist(''iButtonHData_' Tdate '.mat'',''file'')']) == 0
        eval(['Hfile = ''iButtonHData_' Tdate '.mat'';']);
    else
        eval(['disp([''The output file: "iButtonHData' Tdate '.mat" already exists.'']);']);
        writeover = input('Write over existing file? (y/n)','s');
        if strcmp(writeover,'y')
            eval(['Hfile = ''iButtonHData_' Tdate '.mat'';']);
            disp('File will be overwritten.');
        else
            disp('File will not be written over. A new file will be created');
            eval(['Hfile = ''iButtonHData_' Tdate '_' num2str(datenum(Tstamp)) '.mat'';']);
        end
    end
    save(Hfile,'Tstamp');
    % Import data to table and save table to file
    HAdds = cell(length(partsH),1);
    for l = 1:(h-1)
        m = partsH{l,5};
        % Importing data and creating the data arrays for the table
        % Categorical arrays used when possible to reduce space used
        StartLine = detLine(strcat(PathName,FileName{m})); % Data starting point
        [deviceType, deviceAddress] = deviceinfo(strcat(PathName,FileName{m}),1,2); % Device physical address
        HAdds{l} = deviceAddress;
        DUVmatrix = importifile(strcat(PathName,FileName{m}),HUnit,StartLine);
        if strcmp(correctD,'y')
            DUVmatrix(:,1) = DUVmatrix(:,1) + corrTZ;
        end
        tLim = tableLimits(DUVmatrix(:,1),method,true);
        for i = 1:size(tLim,1)
            if i == size(tLim,1)
                if tLim(i,2) == size(DUVmatrix,1)
                    break %If only one entry exist then no separate tables are created
                end
                last = size(DUVmatrix,1);
            else
                last = tLim(i+1,2)-1;
            end
            [Y,M] = datevec(tLim(i,1));
            if tLim(i,3) == 1
                comp = 'c';
            else
                comp = 'i';
            end
            yrs = [num2str(Y-2000),num2str(Y-1999),comp];
            eval(['Mname = ''H_' deviceType '_' deviceAddress '_' yrs ''';'])
            eval([Mname ' = DUVmatrix(tLim(i,2):last,:);'])
            eval(['save(Hfile,''' Mname ''',''-append'')'])
        end
    end
end
disp('Work complete.');
% [*]